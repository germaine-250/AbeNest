const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
const toast = document.getElementById("toast");

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  window.setTimeout(() => toast.classList.remove("show"), 2600);
}

menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});

mainNav.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  });
});

document.querySelectorAll("[data-open-modal]").forEach((button) => {
  button.addEventListener("click", () => {
    const modal = document.getElementById(button.dataset.openModal);
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
  });
});

document.querySelectorAll("[data-close-modal]").forEach((element) => {
  element.addEventListener("click", () => {
    const modal = element.closest(".modal");
    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");
  });
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    document.querySelectorAll(".modal.open").forEach((modal) => {
      modal.classList.remove("open");
      modal.setAttribute("aria-hidden", "true");
    });
  }
});

document.querySelectorAll(".mood-option").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".mood-option").forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    document.getElementById("moodFeedback").textContent =
      `Thank you for checking in. You selected: ${button.dataset.mood}.`;
  });
});

const cycleForm = document.getElementById("cycleForm");

cycleForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const lastPeriodValue = document.getElementById("lastPeriod").value;
  const cycleLength = Number(document.getElementById("cycleLength").value);
  const periodLength = Number(document.getElementById("periodLength").value);

  if (!lastPeriodValue) {
    showToast("Please select the first day of your last period.");
    return;
  }

  const lastPeriod = new Date(`${lastPeriodValue}T12:00:00`);
  const today = new Date();
  today.setHours(12, 0, 0, 0);

  const daysSince = Math.floor((today - lastPeriod) / 86400000);
  const normalizedDay = ((daysSince % cycleLength) + cycleLength) % cycleLength + 1;

  const nextPeriod = new Date(lastPeriod);
  while (nextPeriod <= today) {
    nextPeriod.setDate(nextPeriod.getDate() + cycleLength);
  }

  const ovulationDay = new Date(nextPeriod);
  ovulationDay.setDate(ovulationDay.getDate() - 14);

  const fertileStart = new Date(ovulationDay);
  fertileStart.setDate(fertileStart.getDate() - 5);

  const fertileEnd = new Date(ovulationDay);
  fertileEnd.setDate(fertileEnd.getDate() + 1);

  const formatter = new Intl.DateTimeFormat("en", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });

  document.getElementById("cycleDayResult").textContent = normalizedDay;
  document.getElementById("nextPeriodResult").textContent = formatter.format(nextPeriod);
  document.getElementById("fertileResult").textContent =
    `${formatter.format(fertileStart)} – ${formatter.format(fertileEnd)}`;
  document.getElementById("periodDurationResult").textContent = `${periodLength} days`;
  document.getElementById("heroCycleDay").textContent = normalizedDay;

  const daysUntil = Math.max(0, Math.ceil((nextPeriod - today) / 86400000));
  document.getElementById("heroNextPeriod").textContent =
    daysUntil === 0 ? "Estimated today" : `In ${daysUntil} day${daysUntil === 1 ? "" : "s"}`;

  showToast("Cycle estimate updated.");
});

const selectedSymptoms = new Set();

document.querySelectorAll("#symptomGrid button").forEach((button) => {
  button.addEventListener("click", () => {
    const symptom = button.dataset.symptom;

    if (selectedSymptoms.has(symptom)) {
      selectedSymptoms.delete(symptom);
      button.classList.remove("active");
    } else {
      selectedSymptoms.add(symptom);
      button.classList.add("active");
    }

    document.getElementById("symptomFeedback").textContent =
      selectedSymptoms.size === 0
        ? "Select any symptoms you want to log."
        : `Logged today: ${Array.from(selectedSymptoms).join(", ")}.`;
  });
});

document.querySelectorAll("#articleFilters .filter").forEach((filterButton) => {
  filterButton.addEventListener("click", () => {
    document.querySelectorAll("#articleFilters .filter").forEach((item) => item.classList.remove("active"));
    filterButton.classList.add("active");

    const category = filterButton.dataset.category;

    document.querySelectorAll(".article-card").forEach((card) => {
      const shouldShow = category === "all" || card.dataset.category === category;
      card.style.display = shouldShow ? "" : "none";
    });
  });
});

const articleContent = {
  cycleArticle: {
    category: "My period",
    title: "What is a normal menstrual cycle?",
    body: `
      <p>Menstrual cycles can vary from person to person. A cycle is counted from the first day of one period to the first day of the next.</p>
      <p>Changes can happen because of stress, illness, travel, sleep, weight changes, medication, or normal hormonal variation.</p>
      <p>Consider speaking with a qualified healthcare professional when bleeding is extremely heavy, pain is severe, periods suddenly change for several months, or you are worried about pregnancy.</p>
      <p><strong>Important:</strong> cycle predictions are estimates and should not be used as guaranteed contraception.</p>
    `,
  },
  dischargeArticle: {
    category: "My body",
    title: "Understanding vaginal discharge",
    body: `
      <p>Clear or white discharge can be a normal part of the menstrual cycle. Its amount and texture can change during the month.</p>
      <p>Seek professional advice when discharge has a strong unpleasant smell, is accompanied by severe itching or pain, or has an unusual colour that worries you.</p>
      <p>Avoid putting harsh products inside the vagina. The vagina naturally cleans itself.</p>
    `,
  },
  selfCareArticle: {
    category: "Well-being",
    title: "Being kinder to yourself on difficult days",
    body: `
      <p>Rest is not laziness. On difficult days, try reducing your expectations and choosing one small helpful action.</p>
      <p>You might drink water, take a short walk, write down what you feel, speak to someone you trust, or sleep earlier.</p>
      <p>If sadness, anxiety, or hopelessness becomes intense or persistent, reach out to a qualified mental health professional or trusted support person.</p>
    `,
  },
  skillsArticle: {
    category: "My future",
    title: "How to begin building your skills",
    body: `
      <p>Choose one useful skill that connects to your goals. Break it into small weekly topics, practise regularly, and create small projects.</p>
      <p>Do not wait until you feel fully ready. Progress becomes visible after repeated practice.</p>
      <p>Save examples of your work so you can later build a portfolio for internships, scholarships, clients, or jobs.</p>
    `,
  },
};

document.querySelectorAll("[data-open-article]").forEach((button) => {
  button.addEventListener("click", () => {
    const article = articleContent[button.dataset.openArticle];
    document.getElementById("articleCategory").textContent = article.category;
    document.getElementById("articleTitle").textContent = article.title;
    document.getElementById("articleBody").innerHTML = article.body;

    const modal = document.getElementById("articleModal");
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
  });
});

document.getElementById("askForm").addEventListener("submit", (event) => {
  event.preventDefault();

  const question = document.getElementById("privateQuestion").value.trim();
  const response = document.getElementById("askResponse");

  response.classList.remove("hidden");
  response.innerHTML = `
    <strong>Thank you for asking.</strong>
    <p>Your question has been received in this prototype. A production version should use reviewed health content and route urgent concerns to verified professional help.</p>
    <p>For now, avoid using a website response as a diagnosis. Seek qualified medical care for severe pain, heavy bleeding, breathing difficulty, fainting, possible pregnancy complications, violence, or any situation that feels urgent.</p>
  `;

  event.target.reset();
});

const topicData = {
  "Period Talk": "What is one thing you wish someone had explained before your first period?",
  "Girls in Tech": "Which technology skill would you like to learn this year, and why?",
  "Confidence Corner": "What is one quality you appreciate about yourself that is not related to appearance?",
  "School and University": "What study habit has helped you most during a difficult semester?",
  Entrepreneurship: "What small problem in your community would you like to solve through a project or business?",
};

document.querySelectorAll(".topic").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".topic").forEach((item) => item.classList.remove("active"));
    button.classList.add("active");

    const topic = button.dataset.topic;
    document.getElementById("topicTitle").textContent = topic;
    document.getElementById("topicDescription").textContent = topicData[topic];
  });
});

document.querySelectorAll(".poll button").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".poll button").forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    document.getElementById("pollMessage").textContent =
      `Your answer was recorded in this demo: ${button.dataset.poll}.`;
  });
});

document.querySelectorAll("[data-demo-message]").forEach((button) => {
  button.addEventListener("click", () => showToast(button.dataset.demoMessage));
});

document.getElementById("quickExit").addEventListener("click", () => {
  window.location.href = "https://www.google.com";
});

document.querySelectorAll(".save-button").forEach((button) => {
  button.addEventListener("click", () => {
    const saved = button.classList.toggle("saved");
    button.textContent = saved ? "Saved" : "Save opportunity";
  });
});

document.getElementById("contactForm").addEventListener("submit", (event) => {
  event.preventDefault();
  document.getElementById("contactStatus").textContent =
    "Demo only: connect this form to a secure backend before publishing.";
  showToast("Message prepared in demo mode.");
});

document.getElementById("joinForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const name = document.getElementById("joinName").value.trim();
  document.getElementById("joinStatus").textContent =
    `Welcome, ${name || "friend"}. This prototype does not create a real account yet.`;
});

document.getElementById("loginForm").addEventListener("submit", (event) => {
  event.preventDefault();
  document.getElementById("loginStatus").textContent =
    "Demo login only. Connect secure authentication before publishing.";
});

document.getElementById("currentYear").textContent = new Date().getFullYear();

const today = new Date();
document.getElementById("lastPeriod").valueAsDate = new Date(
  today.getFullYear(),
  today.getMonth(),
  today.getDate() - 11
);
cycleForm.requestSubmit();
