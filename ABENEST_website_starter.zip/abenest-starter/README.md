# ABENEST Starter Website

This folder contains a responsive front-end prototype for ABENEST.

## Files

- `index.html` — complete page structure
- `style.css` — colours, layout, responsiveness, cards, modals, and mobile navigation
- `script.js` — menu, modals, cycle estimate demo, symptom logging, filters, polls, and forms

## How to run it

1. Open the folder in Visual Studio Code.
2. Install the **Live Server** extension.
3. Right-click `index.html`.
4. Select **Open with Live Server**.

You can also double-click `index.html`, but Live Server is better while editing.

## Important safety note

This is only a front-end prototype.

The following are demos and are not connected to a database or server:

- Account registration
- Login
- Contact form
- Ask ABENEST
- Community posts and polls
- Saving opportunities
- Support directory

Before using this publicly, add:

- secure authentication
- a backend API
- a database
- reviewed health content
- verified Rwanda-based support information
- privacy policy and consent flows
- moderation tools
- secure storage and account deletion

Do not invent hotline numbers, hospitals, legal resources, or medical claims. Verify them before publication.

## Recommended next step

Personalize the text, logo, photos/illustrations, and contact information first. Then build the backend feature by feature.
